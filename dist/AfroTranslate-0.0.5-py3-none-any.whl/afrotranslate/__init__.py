from .translator import MasakhaneTranslate
